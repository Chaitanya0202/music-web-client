import {
  BrowserRouter as Router,
  Route,
  Switch,
  Routes,
} from "react-router-dom";
import "./App.css";
import Navbar from "./Components/Navbaar";
import Home from "./Components/Home";
import Contact from "./Components/Contact";
import Event from "./Components/Event";
import UserTable from "./Components/AllUser";
import BookingForm from "./Components/Booking";
import Footer from "./Components/Footer";

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar/>
        <Routes>
          <Route exact path="/"  element={<Home/>} />
          
          <Route exact path="/contact" element={<Contact/>} />
          <Route exact path="/event" element={<Event/>} />
          <Route exact path="/getAllUser" element={<UserTable/>} />
          <Route exact path="/book" element={<BookingForm/>} />
          
          </Routes>
          </div>
          <Footer/>
    </Router>
  );
}

export default App;
