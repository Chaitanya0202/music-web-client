import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-purple-900 text-white py-6">
      <div className="container mx-auto flex flex-col items-center">
        <p className="text-lg font-semibold mb-4">Connect with us:</p>
        <div className="flex space-x-4">
          <a href="#" className="hover:text-purple-500">
            Facebook
          </a>
          <a href="#" className="hover:text-purple-500">
            Twitter
          </a>
          <a href="#" className="hover:text-purple-500">
            LinkedIn
          </a>
          <a href="#" className="hover:text-purple-500">
            Instagram
          </a>
        </div>
        <p className="mt-4">© 2024 Your Company. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
